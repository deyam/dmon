WebJar for angular-router

More info: http://webjars.org

Upstream: https://github.com/angular/router
