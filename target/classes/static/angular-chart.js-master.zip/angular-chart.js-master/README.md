WebJar for angular-chart.js

More info: http://webjars.org

Upstream: https://github.com/jtblin/angular-chart.js
